﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class ButtonController : MonoBehaviour
{
	public Text clear;
	public Text topSliderValueText;
	
	public void showTopSilderValue(Slider mySlider)
	{
		topSliderValueText.text = mySlider.value.ToString();
	}
	
	public void textClear()
	{
		clear.text = "";
	}
}