﻿using UnityEngine;
using System.Collections;

public class Control : MonoBehaviour
{
	private Animator animator;
	
	void Start()
	{
		animator = GetComponent<Animator>();
	}
	
	void Update()
	{
		if(Input.GetAxis("Horizontal") > 0)
		{
			animator.SetInteger("Direction", 1);
		}
		else if(Input.GetAxis("Horizontal") < 0)
		{
			animator.SetInteger("Direction", 3);
		}
		else if(Input.GetAxis("Vertical") < 0)
		{
			animator.SetInteger("Direction", 2);
		}
		else if(Input.GetAxis("Vertical") > 0)
		{
			animator.SetInteger("Direction", 0);
		}
	}
}