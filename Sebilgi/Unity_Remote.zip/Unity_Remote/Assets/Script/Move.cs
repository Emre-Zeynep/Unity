﻿using UnityEngine;
using System.Collections;

public class Move : MonoBehaviour
{
	float x;
	float y;
	
	void Start()
	{
	
	}
	
	void Update()
	{
		if(Input.touchCount == 1)
		{
			Touch touch = Input.GetTouch(0);
			x =- 7.5f + 15 * touch.position.x / Screen.width;
			y =- 4.5f + 9 * touch.position.y / Screen.height;
			transform.position = new Vector3(x, y, 0);
		}
	}
}