﻿using UnityEngine;
using UnityEditor;
using System.Collections;

public class MakeObject
{
	[MenuItem("Assets/Create/MyObject")]
	public static void CreateMyAsset()
	{
		MyObject asset = ScriptableObject.CreateInstance<MyObject>();
		AssetDatabase.CreateAsset(asset, "Assets/New_MyObject.asset");
		AssetDatabase.SaveAssets();
	}
}