﻿using UnityEngine;
using System.Collections;

public class UseMyObject : MonoBehaviour
{
	public MyObject myObject;
	Light theLight;
	
	void Start()
	{
		Vector3 spawn = myObject.spawnPoint;
		GameObject myLight = new GameObject("Light");
		myLight.AddComponent<Light>();
		myLight.transform.position = spawn;
		myLight.GetComponent<Light>().color = myObject.thisColor;
		theLight = myLight.GetComponent<Light>();
	}
	
	void Update()
	{
		if(Input.GetButtonDown("Fire1"))
		{
			theLight.enabled = (!theLight.enabled);
		}
	}
}