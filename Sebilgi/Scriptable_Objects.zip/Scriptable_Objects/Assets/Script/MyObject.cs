﻿using UnityEngine;
using System.Collections;

[System.Serializable]

public class MyObject : ScriptableObject
{
	public Color thisColor = Color.white;
	public Vector3 spawnPoint;

}