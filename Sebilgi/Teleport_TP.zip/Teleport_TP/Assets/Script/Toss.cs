﻿using UnityEngine;
using System.Collections;

public class Toss : MonoBehaviour
{
	public GameObject diskPrefab;
	public Transform tossPoint;
	GameObject disk;
	
	void Start()
	{
		disk = (GameObject)Instantiate(diskPrefab);
		disk.GetComponent<Disk>().player = gameObject;
		disk.SetActive(false);
	}
	
	void Update()
	{
		if(Input.GetButtonDown("Fire1"))
		{
			disk.GetComponent<Rigidbody>().velocity = Vector3.zero;
			disk.transform.position = tossPoint.position;
			disk.transform.rotation = tossPoint.rotation;
			disk.SetActive(true);
			disk.GetComponent<Rigidbody>().AddRelativeForce(0, 7, 9, ForceMode.Impulse);
		}
	}
}