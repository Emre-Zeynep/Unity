﻿using UnityEngine;
using System.Collections;

public class Disk : MonoBehaviour
{
	public GameObject player;
	
	void OnTriggerEnter(Collider other)
	{
		if(other.tag == "Player")
		{
			return;
		}
		Invoke("WaitForDeactivate", .2f);
		player.transform.position = new Vector3(transform.position.x, 1f, transform.position.z);
	}
	
	void WaitForDeactivate()
	{
		gameObject.SetActive(false);
	}
	
	void Start()
	{
	
	}
	
	void Update()
	{
	
	}
}