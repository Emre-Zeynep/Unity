﻿using UnityEngine;
using System.Collections;

public class ProjectileDragging : MonoBehaviour
{
	public LineRenderer catapultLineFront;
	public LineRenderer catapultLineBack;
	public float maxStretch = 3.0f;
	
	bool clickedOn;
	SpringJoint2D spring;
	Vector2 prevVelocity;
	Ray leftCatapultToProjectile;
	float circleRadius;
	Transform cutapult;
	Ray rayToMouse;
	float maxStretchSqr;
	
	void OnMouseDown()
	{
		clickedOn = true;
	}
	
	void OnMouseUp()
	{
		GetComponent<Rigidbody2D>().isKinematic = false;
		clickedOn = false;
	}
	
	void Awake()
	{
		spring = GetComponent<SpringJoint2D>();
		cutapult = spring.connectedBody.transform;
	}

	void Start()
	{
		LineRendererSetup();
		rayToMouse = new Ray(cutapult.position, Vector3.zero);
		leftCatapultToProjectile = new Ray(catapultLineFront.transform.position, Vector3.zero);
		CircleCollider2D circle = GetComponent<Collider2D>() as CircleCollider2D;
		circleRadius = circle.radius;
		
		maxStretchSqr = maxStretch * maxStretch;
	}
	
	void Update()
	{
		if(clickedOn)
		{
			Dragging();
		}
		
		if(spring != null)
		{
			if(!GetComponent<Rigidbody2D>().isKinematic && prevVelocity.sqrMagnitude > GetComponent<Rigidbody2D>().velocity.sqrMagnitude)
			{
				Destroy(spring);
				GetComponent<Rigidbody2D>().velocity = prevVelocity;
			}
		}
		else
		{
			catapultLineFront.enabled = false;
			catapultLineBack.enabled = false;
		}
		
		prevVelocity = GetComponent<Rigidbody2D>().velocity;
		
		LineRendererUpdate();
	}
	
	void Dragging()
	{
		Vector3 mouseWorldPoint = Camera.main.ScreenToWorldPoint(Input.mousePosition);
		Vector2 catapultToMouse = mouseWorldPoint - cutapult.position;
		if(catapultToMouse.sqrMagnitude > maxStretchSqr)
		{
			rayToMouse.direction = catapultToMouse;
			mouseWorldPoint = rayToMouse.GetPoint(maxStretch);
		}
		mouseWorldPoint.z = 0f;
		transform.position = mouseWorldPoint;
	}
	
	void LineRendererSetup()
	{
		catapultLineFront.SetPosition(0, catapultLineFront.transform.position);
		catapultLineBack.SetPosition(0, catapultLineBack.transform.position);
		
		catapultLineFront.sortingLayerName = "ForeGraound";
		catapultLineBack.sortingLayerName = "ForeGraound";
		
		catapultLineFront.sortingOrder = 3;
		catapultLineBack.sortingOrder = 1;
	}
	
	void LineRendererUpdate()
	{
		Vector2 catapultToProjectile = transform.position - catapultLineFront.transform.position;
		leftCatapultToProjectile.direction = catapultToProjectile;
		
		Vector3 holdPoint = leftCatapultToProjectile.GetPoint(catapultToProjectile.magnitude + circleRadius);
		
		catapultLineFront.SetPosition(1, holdPoint);
		catapultLineBack.SetPosition(1, holdPoint);
	}
}