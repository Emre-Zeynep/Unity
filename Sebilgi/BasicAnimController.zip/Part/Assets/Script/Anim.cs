﻿using UnityEngine;
using System.Collections;

public class Anim : MonoBehaviour
{
	private Animator anim;
	
	void Start()
	{
		anim = GetComponent<Animator>();
	}
	
	void Update()
	{
		if(Input.GetButton("Fire1"))
		{
			anim.SetBool("zipla", true);
		}
		else
		{
			anim.SetBool("zipla", false);
		}
	}
}