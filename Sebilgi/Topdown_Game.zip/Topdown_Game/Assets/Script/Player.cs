﻿using UnityEngine;
using System.Collections;

public class Player : MonoBehaviour
{
	public float speed;
	float input;
	
	void FixedUpdate()
	{
		var mousePosition = Camera.main.ScreenToWorldPoint(Input.mousePosition);
		Quaternion rot = Quaternion.LookRotation(transform.position - mousePosition, Vector3.forward);
		transform.rotation = rot;
		transform.eulerAngles = new Vector3(0,0, transform.eulerAngles.z);
		
		input = Input.GetAxis("Vertical");
		GetComponent<Rigidbody2D>().AddForce(gameObject.transform.up * speed * input);
		
	}
	
	void Start()
	{
	
	}
	
	void Update()
	{
	
	}
}