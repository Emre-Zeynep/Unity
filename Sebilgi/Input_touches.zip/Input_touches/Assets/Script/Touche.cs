﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class Touche : MonoBehaviour
{
	public Text durum;
	string message;
	
	void Update()
	{
		foreach(Touch touch in Input.touches)
		{
			message = "";
			message += "ID: " + touch.fingerId + "\n";
			message += "Phase: " + touch.phase + "\n";
			message += "TapCount: " + touch.tapCount + "\n";
			message += "Pos X: " + (int)touch.position.x + "\n";
			message += "Pos Y: " + (int)touch.position.y + "\n";
		}
		durum.text = message;
	}
}