﻿using UnityEngine;
using System.Collections;

public class FireObject : MonoBehaviour
{
	public GameObject obj;
	public float fireTime = 0.5f;

	void Start()
	{
		InvokeRepeating("Fire", fireTime, fireTime);
	}
	
	void Update()
	{
	
	}
	
	void Fire()
	{
		GameObject obj = GameObject.Find("ObjectPool").GetComponent<ObjectPool>().GetPooledObject();
		obj.transform.position = transform.position;
		obj.SetActive(true);
	}
}