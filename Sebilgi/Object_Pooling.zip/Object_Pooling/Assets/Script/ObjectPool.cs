﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class ObjectPool : MonoBehaviour
{
	List<GameObject> pooledObjects;
	public int pooledAmount = 10;
	public GameObject redCube;

	void Start()
	{
		pooledObjects = new List<GameObject>();
		for(int i=0; i<pooledAmount; i++)
		{
			GameObject obj = (GameObject)Instantiate(redCube);
			obj.SetActive(false);
			pooledObjects.Add(obj);
		}
	}
	
	public GameObject GetPooledObject()
	{
		for(int i=0; i<pooledAmount; i++)
		{
			if(!pooledObjects[i].activeInHierarchy)
			{
				return pooledObjects[i];
			}
		}
		return null;
	}
}