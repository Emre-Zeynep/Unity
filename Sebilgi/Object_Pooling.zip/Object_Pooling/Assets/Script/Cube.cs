﻿using UnityEngine;
using System.Collections;

public class Cube : MonoBehaviour
{
	void OnEnable()
	{
		Invoke("Destroy", 4f);
	}
	
	void Destroy()
	{
		gameObject.SetActive(false);
		gameObject.GetComponent<Rigidbody>().velocity = new Vector3(0,0,0);
	}
	
	void OnDisable()
	{
		CancelInvoke();
	}

	void Start()
	{
		
	}
	
	void Update()
	{
		
	}
}