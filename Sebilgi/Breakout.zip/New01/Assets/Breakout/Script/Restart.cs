﻿using UnityEngine;
using System.Collections;

public class Restart : MonoBehaviour
{
	void Start()
	{
		Destroy(GameObject.Find("Paddle"));
		Destroy(GameObject.Find("Canvas"));
	}

	void Update()
	{
	
	}
	
	public void restartGame()
	{
		Application.LoadLevel(0);
	}
}