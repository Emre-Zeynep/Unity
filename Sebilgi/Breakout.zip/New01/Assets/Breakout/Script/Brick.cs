﻿using UnityEngine;
using System.Collections;

public class Brick : MonoBehaviour
{
	static int numBricks = 0;
	public int hitPoints = 1;
	public int scorePoints = 1;
	
	void Start()
	{
		numBricks++;
	}
	
	void Update()
	{
	
	}
	
	void OnCollisionEnter(Collision coll)
	{
		hitPoints--;
		if(hitPoints <= 0)
		{
			Die();
		}
	}
	
	void Die()
	{
		Destroy(gameObject);
		GameObject.Find("Paddle").GetComponent<Paddle>().addScore(scorePoints);
		numBricks--;
		if(numBricks <= 0)
		{
			Application.LoadLevel("Level_2");
		}
	}
}