﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class Paddle : MonoBehaviour
{
	public GameObject prefabBall;
	public Canvas myCanvas;
	public Text scoreText;
	
	GameObject attachedBall = null;
	int Lives = 4;
	int Score = 0;
	
	void Start()
	{
		DontDestroyOnLoad(gameObject);
		DontDestroyOnLoad(myCanvas);
		LooseLife();
	}
	
	void Update()
	{
		if(attachedBall)
		{
			attachedBall.GetComponent<Rigidbody>().position = transform.position + new Vector3(0, 0.7f, 0);
			if(Input.GetButtonDown("Jump"))
			{
				attachedBall.GetComponent<Rigidbody>().isKinematic = false;
				attachedBall.GetComponent<Rigidbody>().AddForce(300f * Input.GetAxis("Horizontal"), 300f, 0);
				attachedBall = null;
			}
		}
		
		transform.Translate(10f * Time.deltaTime * Input.GetAxis("Horizontal"), 0, 0);
		
		if(transform.position.x < -2.52f)
		{
			transform.position = new Vector3(-2.52f, transform.position.y, transform.position.z);
		}
		
		if(transform.position.x > 2.52f)
		{
			transform.position = new Vector3(2.52f, transform.position.y, transform.position.z);
		}
		
	}
	
	void OnCollisionEnter(Collision col)
	{
		foreach(ContactPoint contact in col.contacts)
		{
			if(contact.thisCollider == GetComponent<Collider>())
			{
				float kayma = contact.point.x - transform.position.x;
				contact.otherCollider.GetComponent<Rigidbody>().AddForce(300f * kayma,0,0);
			}
		}
	}
	
	void SpawnBall()
	{
		attachedBall = (GameObject)Instantiate(prefabBall, transform.position + new Vector3(0, 0.7f, 0), Quaternion.identity);
		KinematicController();
	}
	
	void OnDestroy()
	{
		Destroy(attachedBall);
	}
	
	public void OnLevelWasLoaded(int level)
	{
		if(Application.loadedLevelName != "Level_1")
		{
			SpawnBall();
		}
		
	}
	
	public void addScore(int v)
	{
		Score += v;
		scoreText.text = "Score: " + Score;
	}
	
	public void LooseLife()
	{
		Lives--;
		if(Lives <= 0)
		{
			Application.LoadLevel("Game_Over");
		}
		myCanvas.GetComponentInChildren<Text>().text = "Lives: " + Lives;
		SpawnBall();
	}
	
	void KinematicController()
	{
		if(attachedBall.GetComponent<Rigidbody>().isKinematic != true)
		{
			attachedBall.GetComponent<Rigidbody>().isKinematic = true;
		}
		else
		{
			attachedBall.GetComponent<Rigidbody>().isKinematic = false;
		}
	}
}