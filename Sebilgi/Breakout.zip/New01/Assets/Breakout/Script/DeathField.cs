﻿using UnityEngine;
using System.Collections;

public class DeathField : MonoBehaviour
{
	void Start()
	{
		
	}
	
	void Update()
	{
		
	}
	
	void OnTriggerEnter(Collider other)
	{
		Ball ball = other.GetComponent<Ball>();
		ball.Die();
	}
}