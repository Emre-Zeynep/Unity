﻿using UnityEngine;
using System.Collections;

public class Ball : MonoBehaviour
{
	void Start ()
	{
	
	}
	
	void Update()
	{
	
	}
	
	public void Die()
	{
		Destroy(gameObject);
		GameObject paddeleObject = GameObject.Find("Paddle");
		Paddle paddle = paddeleObject.GetComponent<Paddle>();
		paddle.LooseLife();
	}
}